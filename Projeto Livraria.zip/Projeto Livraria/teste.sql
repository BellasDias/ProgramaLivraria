
Colocar dps de 'Inserir os intens da venda e atualizar o estoque (frm_Vendas)
------------------------------------------------------------------------

 

' Verificar se possui a quantidade certa mo estoque
                            Dim sqlVerificaEst = "select qtdEstoque, nome from tb_produtos where cod_prod=@cod"
                            Using cmdVerificaEst = New SqlCommand(sqlVerificaEst, conn)
                                cmdVerificaEst.Parameters.AddWithValue("@cod", cod_prod)

                                Using dr As SqlDataReader = cmdVerificaEst.ExecuteReader()
                                    If dr.Read() Then
                                        Dim qtdEstoque As Integer = dr.GetInt32(0)
                                        Dim nomeLivro As String = dr.GetString(1)

                                        If qtdEstoque < qtd Then
                                            MessageBox.Show("Quantidade do livro '" & nomeLivro & "' insuficiente no estoque")
                                            Return
                                        End If
                                    Else
                                        MessageBox.Show("Produto com código '" & cod_prod & "' não encontrado")
                                        Return
                                    End If
                                End Using
                            End Using

------------------------------------------------------------------------

Criar um btn_excluir

adicionar esse PrivateSub ao clicar no botão


------------------------------------------------------------------------

Private Sub btn_excluir_Click(sender As Object, e As EventArgs) Handles btn_excluir.Click
        If dgv_prod.SelectedRows.Count > 0 Then
            For Each row As DataGridViewRow In dgv_prod.SelectedRows
                dgv_prod.Rows.Remove(row)
                CalcTotal()
                ValoresProd()
                ValoresProd()
            Next
        Else
            MsgBox("Nenhum item selecionado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End If
    End Sub