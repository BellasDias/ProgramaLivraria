﻿Public Class frm_userMenu
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        frm_Vendas.ShowDialog()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        frm_cadastro_prod.ShowDialog()
    End Sub
End Class