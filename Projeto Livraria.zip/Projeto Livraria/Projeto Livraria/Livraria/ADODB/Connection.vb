﻿Namespace ADODB
    Public Class Connection
    End Class
End Namespace
