﻿
Imports System.Data.SqlClient
Public Class frm_cadastro_user
    Private Sub btn_cadastrar_Click(sender As Object, e As EventArgs) Handles btn_cadastrar.Click
        NovoUsuario()
    End Sub

    Private Sub ConfirmSenha()
        Try
            If txt_senha.Text <> txt_confirmSenha.Text Then
                MsgBox("As senhas não conferem!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
            Else
                ' MsgBox("Usuário cadastrado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            End If
        Catch ex As Exception
            MsgBox("Algo deu errado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
        End Try
    End Sub

    Private Sub ImportarCargo()
        Try
            Using conn = New SqlConnection(connStr)
                conn.Open()

                Dim sql = "update u set u.cargo = f.cargo from tb_usuarios u join tb_funcionarios f on u.cpf = f.cpf"
                Using cmd = New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@cpf", txt_cpf.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            MsgBox("Algo deu errado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
        End Try
    End Sub

    Private Sub NovoUsuario()
        Try
            ConfirmSenha()
            Using conn = New SqlConnection(connStr)
                conn.Open()

                Dim sql = "select * from tb_usuarios where cpf=@cpf"
                Using cmdCheck = New SqlCommand(sql, conn)
                    cmdCheck.Parameters.AddWithValue("@cpf", txt_cpf.Text)

                    Using dr = cmdCheck.ExecuteReader()
                        If dr.HasRows Then
                            Dim msg = MsgBox("Usuário já cadastrado! Deseja edita-lo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "AVISO")
                            If msg = vbYes Then
                                EditarUsuario()
                            Else
                                LimparCampos()
                            End If
                        Else
                            dr.Close()

                            sql = "insert into tb_usuarios (cpf, usuario, senha) values (@cpf, @usuario, @senha)"
                            Using cmd = New SqlCommand(sql, conn)
                                cmd.Parameters.AddWithValue("@cpf", txt_cpf.Text)
                                cmd.Parameters.AddWithValue("@usuario", txt_user.Text)
                                cmd.Parameters.AddWithValue("@senha", txt_senha.Text)
                                cmd.ExecuteNonQuery()
                                ImportarCargo()
                                'ConfirmSenha()
                                MsgBox("Usuário cadastrado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                            End Using
                        End If
                    End Using

                End Using

            End Using
        Catch ex As Exception
            MsgBox("Algo deu errado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub EditarUsuario()
        Try
            Using conn = New SqlConnection(connStr)
                conn.Open()

                Dim sql = "update tb_usuarios set usuario=@user, senha=@senha where cpf=@cpf"
                Using cmd = New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@cpf", txt_cpf.Text)
                    cmd.Parameters.AddWithValue("@user", txt_user.Text)
                    cmd.Parameters.AddWithValue("@senha", txt_senha.Text)
                    cmd.ExecuteNonQuery()
                    MsgBox("Dados do usuário editado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                End Using
            End Using
        Catch ex As Exception
            MsgBox("Algo deu errado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub LimparCampos()
        txt_cpf.Clear()
        txt_senha.Clear()
        txt_confirmSenha.Clear()
        txt_user.Clear()
        txt_user.Focus()
    End Sub

    Private Sub txt_cpf_TextChanged(sender As Object, e As EventArgs) Handles txt_cpf.TextChanged
        'Máscara para o CPF
        Dim cpf As String = txt_cpf.Text.Replace(".", "").Replace("-", "").Trim()

        ' Verifica se o CPF está vazio ou tem mais de 11 caracteres
        If cpf.Length = 0 OrElse cpf.Length > 11 Then
            txt_cpf.Text = ""
            Exit Sub
        End If

        ' Aplica a máscara do CPF
        If cpf.Length > 3 Then
            cpf = cpf.Insert(3, ".")
        End If
        If cpf.Length > 7 Then
            cpf = cpf.Insert(7, ".")
        End If
        If cpf.Length > 11 Then
            cpf = cpf.Insert(11, "-")
        End If

        txt_cpf.Text = cpf
        txt_cpf.SelectionStart = txt_cpf.Text.Length ' Coloca o cursor no final do texto

    End Sub

End Class